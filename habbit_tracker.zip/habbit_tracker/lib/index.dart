// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/calendar_page/calendar_page_widget.dart' show CalendarPageWidget;
export '/pages/add_habit/add_habit_widget.dart' show AddHabitWidget;
export '/pages/estadisticas/estadisticas_widget.dart' show EstadisticasWidget;
export '/pages/perfil/perfil_widget.dart' show PerfilWidget;
export '/pages/edit_cuenta/edit_cuenta_widget.dart' show EditCuentaWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/signin/signin_widget.dart' show SigninWidget;
